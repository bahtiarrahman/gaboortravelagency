<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>


<div class="container mt-4 mb-5">
    <h1>Kontak Admin</h1>

    <ul class="list-group">
        <li class="list-group-item">
            Abimanyu Primarendra
            <a href="https://wa.me/+6282223633439" class="btn btn-success float-right" target="_blank">Chat</a>
        </li>
        <li class="list-group-item">
            Adhika Dwiki Septian
            <a href="https://wa.me/6281225787821" class="btn btn-success float-right" target="_blank">Chat</a>
        </li>
        <li class="list-group-item">
            Anggi Nur Khasnah
            <a href="https://wa.me/+6288227523606" class="btn btn-success float-right" target="_blank">Chat</a>
        </li>
        <li class="list-group-item">
            Yulviani Puteri Puspita Sari
            <a href="https://wa.me/+6282260600257" class="btn btn-success float-right" target="_blank">Chat</a>
        </li>
        <li class="list-group-item">
            Bahtiar Rahman
            <a href="https://wa.me/+6281349675235" class="btn btn-success float-right" target="_blank">Chat</a>
        </li>
    </ul>
</div>

</body>
</html>
